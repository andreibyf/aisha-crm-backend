# CRM Backend (Node.js/Express/PostgreSQL/JWT/Webhook)

## Setup

1. **Edit `.env.example` → `.env` with secrets and webhook URL**
2. **Initialize DB:**  
   ```
   docker-compose up postgres
   # Then in a separate terminal:
   docker exec -it <postgres_container_name> psql -U crmuser -d crmdb
   # Run contents of init.sql
   ```
3. **Start the backend:**  
   ```
   docker-compose up --build
   ```
4. **Register first user:**  
   POST to `/api/auth/register` with `{ username, password, tenant_id }`
5. **Login:**  
   POST to `/api/auth/login` with `{ username, password }` to receive JWT

## Endpoints

- `/api/customers` (CRUD, JWT, tenant-aware)
- `/api/accounts` (CRUD, JWT, tenant-aware)
- `/api/auth/login` (JWT token)
- `/api/auth/register` (create user)
- `/api/health` (health check)

## Extending

- Add more entities: see `/routes/accounts.js` for example structure.
- Add more webhook logic in `webhook.js`.
- Integrate with your frontend at `http://localhost:4000`.
