#!/bin/bash

# CRM Full App Setup Script
# Run this from your project root (where docker-compose.yml is located)

set -e

# 1. Check for Docker and Docker Compose
if ! command -v docker &> /dev/null; then
    echo "Docker is not installed. Please install Docker first: https://docs.docker.com/get-docker/"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "Docker Compose is not installed. Please install Docker Compose: https://docs.docker.com/compose/install/"
    exit 1
fi

echo "Docker and Docker Compose found."

# 2. Build and start containers
echo "Building and starting containers..."
docker-compose up -d --build

# 3. Wait for PostgreSQL to be ready
echo "Waiting for PostgreSQL to be ready..."
sleep 10

# 4. Run database migrations/init.sql
echo "Running DB migrations (init.sql)..."
POSTGRES_CONTAINER=$(docker-compose ps -q postgres)
if [ ! -f backend/init.sql ]; then
    echo "Error: backend/init.sql does not exist!"
    exit 1
fi
docker cp backend/init.sql $POSTGRES_CONTAINER:/init.sql
docker exec -u postgres $POSTGRES_CONTAINER psql -U crmuser -d crmdb -f /init.sql

# 5. Instructions for first user registration
echo ""
echo "Setup finished!"
echo ""
echo "Next steps:"
echo "1. Register your first user via:"
echo "   curl -X POST http://localhost:4000/api/auth/register \\"
echo "        -H 'Content-Type: application/json' \\"
echo "        -d '{\"username\":\"admin\",\"password\":\"yourpassword\",\"tenant_id\":1}'"
echo ""
echo "2. Login and use your app:"
echo "   - Frontend: http://localhost:3000"
echo "   - Backend API: http://localhost:4000"
echo ""
echo "3. If you want to rebuild containers: docker-compose up -d --build"
echo "4. To stop everything: docker-compose down"
echo ""